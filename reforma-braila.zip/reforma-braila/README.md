# Reformă Administrativă Brăila

Simulator de comasare a celor 44 de UAT din județul Brăila: populație (RPL 2021), venituri proprii vs. cheltuieli, grupări editabile și scenarii automate.

## Ce face aplicația

- **Situație actuală**: harta UAT-urilor colorată după populație sau, după importul datelor financiare, după cele 4 categorii:
  sub personal administrativ / între personal administrativ și total / între personal total și funcționare / peste funcționare.
- **Editează**: pornești de la propunerea cu 5 UAT (Brăila, Ianca, Făurei, Însurăței, Șuțești – Nord-Vest) sau de la zero și muți comunele între grupări cu un clic. Pentru fiecare grupare vezi populația, veniturile, cheltuielile după comasare și gradul de acoperire.
- **Scenariu automat**: comasează UAT-urile vecine până trec de un prag (5.000, 10.000 etc.) și, opțional, până își acoperă funcționarea din venituri proprii.
- **Date**: import CSV cu datele financiare, import GeoJSON cu contururile, export scenariu CSV.

Economia la comasare se setează din glisor: procentul din cheltuielile cu personalul administrativ care dispare când mai multe primării devin una (implicit 40%).

## Publicare pe GitHub Pages (gratuit)

1. Creează un cont pe github.com și un repository nou, de exemplu `reforma-braila` (Public).
2. Încarcă fișierele `index.html` (și opțional `braila.geojson`, `braila_date_financiare.csv`) cu **Add file → Upload files**.
3. **Settings → Pages → Source: Deploy from a branch**, ramura `main`, folderul `/ (root)` → **Save**.
4. După 1–2 minute aplicația e la `https://<utilizator>.github.io/reforma-braila/`.

Poți deschide `index.html` și direct din calculator (dublu clic), fără publicare.

## Contururile UAT

La prima pornire aplicația descarcă limitele comunelor din OpenStreetMap (Overpass API) și le păstrează în browser.
Ca să pornească instant pentru toată lumea: fila **Date → Salvează braila.geojson**, apoi încarcă fișierul în repository lângă `index.html`.
Poți folosi și limitele oficiale ANCPI (geoportal.ancpi.ro), convertite în GeoJSON WGS84, cu numele UAT în proprietatea `name`.

## Datele financiare

Completează `braila_date_financiare.csv` (separator `;`, sume în lei) pentru anul 2025:

| coloană | ce conține |
|---|---|
| `venituri_proprii` | impozite și taxe locale + venituri din activitate proprie + cota de 63% din impozitul pe venit |
| `personal_administrativ` | cheltuieli de personal pentru aparatul primăriei (autorități executive, COFOG 51.02) |
| `personal_total` | toate cheltuielile de personal (titlul 10) |
| `cheltuieli_functionare` | cheltuieli curente: personal + bunuri și servicii (titlurile 10 + 20) |

Surse: execuțiile bugetare pe UAT ale Ministerului Finanțelor (rapoartele COFOG3 de pe extranet.anaf.mfinante.gov.ro) și transparenta-bugetara.gov.ro.
Apoi: fila **Date → Încarcă CSV**.

## Surse

- Populație: INS, Recensământul Populației și Locuințelor 2021, date pe UAT publicate de DRS Brăila.
- Hartă: © OpenStreetMap contributors, © CARTO.
